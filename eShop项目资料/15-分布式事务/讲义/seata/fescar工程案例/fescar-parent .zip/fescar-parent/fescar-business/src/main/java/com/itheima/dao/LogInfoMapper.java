package com.itheima.dao;

import com.itheima.pojo.LogInfo;
import tk.mybatis.mapper.common.Mapper;

/*****
 * @Author: www.itheima.com
 * @Description: com.itheima.dao
 ****/
public interface LogInfoMapper extends Mapper<LogInfo> {
}
