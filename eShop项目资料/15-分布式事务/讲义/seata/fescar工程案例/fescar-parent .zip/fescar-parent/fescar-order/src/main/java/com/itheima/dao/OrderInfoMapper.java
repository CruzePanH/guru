package com.itheima.dao;
import com.itheima.pojo.OrderInfo;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:shenkunlin
 * @Description:OrderInfo的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface OrderInfoMapper extends Mapper<OrderInfo> {
}
