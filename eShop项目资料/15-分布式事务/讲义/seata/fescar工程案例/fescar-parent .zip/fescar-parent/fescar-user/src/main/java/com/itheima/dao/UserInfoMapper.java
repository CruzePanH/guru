package com.itheima.dao;
import com.itheima.pojo.UserInfo;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:shenkunlin
 * @Description:UserInfo的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface UserInfoMapper extends Mapper<UserInfo> {
}
