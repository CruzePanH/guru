package com.itheima.dao;
import com.itheima.pojo.ItemInfo;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:shenkunlin
 * @Description:ItemInfo的Dao
 * @Date 2019/6/14 0:12
 *****/
public interface ItemInfoMapper extends Mapper<ItemInfo> {
}
